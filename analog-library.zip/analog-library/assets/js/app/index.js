(()=>{var e={452:e=>{var t=function(e){"use strict";var t,r=Object.prototype,n=r.hasOwnProperty,o=Object.defineProperty||function(e,t,r){e[t]=r.value},a="function"==typeof Symbol?Symbol:{},i=a.iterator||"@@iterator",s=a.asyncIterator||"@@asyncIterator",c=a.toStringTag||"@@toStringTag";function l(e,t,r){return Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}),e[t]}try{l({},"")}catch(e){l=function(e,t,r){return e[t]=r}}function u(e,t,r,n){var a=t&&t.prototype instanceof v?t:v,i=Object.create(a.prototype),s=new _(n||[]);return o(i,"_invoke",{value:A(e,r,s)}),i}function p(e,t,r){try{return{type:"normal",arg:e.call(t,r)}}catch(e){return{type:"throw",arg:e}}}e.wrap=u;var d="suspendedStart",h="suspendedYield",f="executing",m="completed",g={};function v(){}function b(){}function y(){}var x={};l(x,i,(function(){return this}));var w=Object.getPrototypeOf,k=w&&w(w(T([])));k&&k!==r&&n.call(k,i)&&(x=k);var C=y.prototype=v.prototype=Object.create(x);function j(e){["next","throw","return"].forEach((function(t){l(e,t,(function(e){return this._invoke(t,e)}))}))}function S(e,t){function r(o,a,i,s){var c=p(e[o],e,a);if("throw"!==c.type){var l=c.arg,u=l.value;return u&&"object"==typeof u&&n.call(u,"__await")?t.resolve(u.__await).then((function(e){r("next",e,i,s)}),(function(e){r("throw",e,i,s)})):t.resolve(u).then((function(e){l.value=e,i(l)}),(function(e){return r("throw",e,i,s)}))}s(c.arg)}var a;o(this,"_invoke",{value:function(e,n){function o(){return new t((function(t,o){r(e,n,t,o)}))}return a=a?a.then(o,o):o()}})}function A(e,r,n){var o=d;return function(a,i){if(o===f)throw new Error("Generator is already running");if(o===m){if("throw"===a)throw i;return{value:t,done:!0}}for(n.method=a,n.arg=i;;){var s=n.delegate;if(s){var c=O(s,n);if(c){if(c===g)continue;return c}}if("next"===n.method)n.sent=n._sent=n.arg;else if("throw"===n.method){if(o===d)throw o=m,n.arg;n.dispatchException(n.arg)}else"return"===n.method&&n.abrupt("return",n.arg);o=f;var l=p(e,r,n);if("normal"===l.type){if(o=n.done?m:h,l.arg===g)continue;return{value:l.arg,done:n.done}}"throw"===l.type&&(o=m,n.method="throw",n.arg=l.arg)}}}function O(e,r){var n=r.method,o=e.iterator[n];if(o===t)return r.delegate=null,"throw"===n&&e.iterator.return&&(r.method="return",r.arg=t,O(e,r),"throw"===r.method)||"return"!==n&&(r.method="throw",r.arg=new TypeError("The iterator does not provide a '"+n+"' method")),g;var a=p(o,e.iterator,r.arg);if("throw"===a.type)return r.method="throw",r.arg=a.arg,r.delegate=null,g;var i=a.arg;return i?i.done?(r[e.resultName]=i.value,r.next=e.nextLoc,"return"!==r.method&&(r.method="next",r.arg=t),r.delegate=null,g):i:(r.method="throw",r.arg=new TypeError("iterator result is not an object"),r.delegate=null,g)}function I(e){var t={tryLoc:e[0]};1 in e&&(t.catchLoc=e[1]),2 in e&&(t.finallyLoc=e[2],t.afterLoc=e[3]),this.tryEntries.push(t)}function P(e){var t=e.completion||{};t.type="normal",delete t.arg,e.completion=t}function _(e){this.tryEntries=[{tryLoc:"root"}],e.forEach(I,this),this.reset(!0)}function T(e){if(null!=e){var r=e[i];if(r)return r.call(e);if("function"==typeof e.next)return e;if(!isNaN(e.length)){var o=-1,a=function r(){for(;++o<e.length;)if(n.call(e,o))return r.value=e[o],r.done=!1,r;return r.value=t,r.done=!0,r};return a.next=a}}throw new TypeError(typeof e+" is not iterable")}return b.prototype=y,o(C,"constructor",{value:y,configurable:!0}),o(y,"constructor",{value:b,configurable:!0}),b.displayName=l(y,c,"GeneratorFunction"),e.isGeneratorFunction=function(e){var t="function"==typeof e&&e.constructor;return!!t&&(t===b||"GeneratorFunction"===(t.displayName||t.name))},e.mark=function(e){return Object.setPrototypeOf?Object.setPrototypeOf(e,y):(e.__proto__=y,l(e,c,"GeneratorFunction")),e.prototype=Object.create(C),e},e.awrap=function(e){return{__await:e}},j(S.prototype),l(S.prototype,s,(function(){return this})),e.AsyncIterator=S,e.async=function(t,r,n,o,a){void 0===a&&(a=Promise);var i=new S(u(t,r,n,o),a);return e.isGeneratorFunction(r)?i:i.next().then((function(e){return e.done?e.value:i.next()}))},j(C),l(C,c,"Generator"),l(C,i,(function(){return this})),l(C,"toString",(function(){return"[object Generator]"})),e.keys=function(e){var t=Object(e),r=[];for(var n in t)r.push(n);return r.reverse(),function e(){for(;r.length;){var n=r.pop();if(n in t)return e.value=n,e.done=!1,e}return e.done=!0,e}},e.values=T,_.prototype={constructor:_,reset:function(e){if(this.prev=0,this.next=0,this.sent=this._sent=t,this.done=!1,this.delegate=null,this.method="next",this.arg=t,this.tryEntries.forEach(P),!e)for(var r in this)"t"===r.charAt(0)&&n.call(this,r)&&!isNaN(+r.slice(1))&&(this[r]=t)},stop:function(){this.done=!0;var e=this.tryEntries[0].completion;if("throw"===e.type)throw e.arg;return this.rval},dispatchException:function(e){if(this.done)throw e;var r=this;function o(n,o){return s.type="throw",s.arg=e,r.next=n,o&&(r.method="next",r.arg=t),!!o}for(var a=this.tryEntries.length-1;a>=0;--a){var i=this.tryEntries[a],s=i.completion;if("root"===i.tryLoc)return o("end");if(i.tryLoc<=this.prev){var c=n.call(i,"catchLoc"),l=n.call(i,"finallyLoc");if(c&&l){if(this.prev<i.catchLoc)return o(i.catchLoc,!0);if(this.prev<i.finallyLoc)return o(i.finallyLoc)}else if(c){if(this.prev<i.catchLoc)return o(i.catchLoc,!0)}else{if(!l)throw new Error("try statement without catch or finally");if(this.prev<i.finallyLoc)return o(i.finallyLoc)}}}},abrupt:function(e,t){for(var r=this.tryEntries.length-1;r>=0;--r){var o=this.tryEntries[r];if(o.tryLoc<=this.prev&&n.call(o,"finallyLoc")&&this.prev<o.finallyLoc){var a=o;break}}a&&("break"===e||"continue"===e)&&a.tryLoc<=t&&t<=a.finallyLoc&&(a=null);var i=a?a.completion:{};return i.type=e,i.arg=t,a?(this.method="next",this.next=a.finallyLoc,g):this.complete(i)},complete:function(e,t){if("throw"===e.type)throw e.arg;return"break"===e.type||"continue"===e.type?this.next=e.arg:"return"===e.type?(this.rval=this.arg=e.arg,this.method="return",this.next="end"):"normal"===e.type&&t&&(this.next=t),g},finish:function(e){for(var t=this.tryEntries.length-1;t>=0;--t){var r=this.tryEntries[t];if(r.finallyLoc===e)return this.complete(r.completion,r.afterLoc),P(r),g}},catch:function(e){for(var t=this.tryEntries.length-1;t>=0;--t){var r=this.tryEntries[t];if(r.tryLoc===e){var n=r.completion;if("throw"===n.type){var o=n.arg;P(r)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(e,r,n){return this.delegate={iterator:T(e),resultName:r,nextLoc:n},"next"===this.method&&(this.arg=t),g}},e}(e.exports);try{regeneratorRuntime=t}catch(e){"object"==typeof globalThis?globalThis.regeneratorRuntime=t:Function("r","regeneratorRuntime = r")(t)}},967:(e,t)=>{"use strict";var r="function"==typeof Symbol&&Symbol.for,n=(r&&Symbol.for("react.element"),r&&Symbol.for("react.portal"),r?Symbol.for("react.fragment"):60107),o=r?Symbol.for("react.strict_mode"):60108,a=r?Symbol.for("react.profiler"):60114,i=r?Symbol.for("react.provider"):60109,s=r?Symbol.for("react.context"):60110,c=(r&&Symbol.for("react.async_mode"),r?Symbol.for("react.concurrent_mode"):60111),l=r?Symbol.for("react.forward_ref"):60112,u=r?Symbol.for("react.suspense"):60113,p=r?Symbol.for("react.suspense_list"):60120,d=r?Symbol.for("react.memo"):60115,h=r?Symbol.for("react.lazy"):60116,f=r?Symbol.for("react.block"):60121,m=r?Symbol.for("react.fundamental"):60117,g=r?Symbol.for("react.responder"):60118,v=r?Symbol.for("react.scope"):60119;t.ForwardRef=l,t.isValidElementType=function(e){return"string"==typeof e||"function"==typeof e||e===n||e===c||e===a||e===o||e===u||e===p||"object"==typeof e&&null!==e&&(e.$$typeof===h||e.$$typeof===d||e.$$typeof===i||e.$$typeof===s||e.$$typeof===l||e.$$typeof===m||e.$$typeof===g||e.$$typeof===v||e.$$typeof===f)}},467:(e,t,r)=>{"use strict";e.exports=r(967)},162:e=>{e.exports=function(){"use strict";return function(e){var t="/*|*/",r=t+"}";function n(t){if(t)try{e(t+"}")}catch(e){}}return function(o,a,i,s,c,l,u,p,d,h){switch(o){case 1:if(0===d&&64===a.charCodeAt(0))return e(a+";"),"";break;case 2:if(0===p)return a+t;break;case 3:switch(p){case 102:case 112:return e(i[0]+a),"";default:return a+(0===h?t:"")}case-2:a.split(r).forEach(n)}}}}()},79:e=>{e.exports=function e(t){"use strict";var r=/^\0+/g,n=/[\0\r\f]/g,o=/: */g,a=/zoo|gra/,i=/([,: ])(transform)/g,s=/,+\s*(?![^(]*[)])/g,c=/ +\s*(?![^(]*[)])/g,l=/ *[\0] */g,u=/,\r+?/g,p=/([\t\r\n ])*\f?&/g,d=/:global\(((?:[^\(\)\[\]]*|\[.*\]|\([^\(\)]*\))*)\)/g,h=/\W+/g,f=/@(k\w+)\s*(\S*)\s*/,m=/::(place)/g,g=/:(read-only)/g,v=/\s+(?=[{\];=:>])/g,b=/([[}=:>])\s+/g,y=/(\{[^{]+?);(?=\})/g,x=/\s{2,}/g,w=/([^\(])(:+) */g,k=/[svh]\w+-[tblr]{2}/,C=/\(\s*(.*)\s*\)/g,j=/([\s\S]*?);/g,S=/-self|flex-/g,A=/[^]*?(:[rp][el]a[\w-]+)[^]*/,O=/stretch|:\s*\w+\-(?:conte|avail)/,I=/([^-])(image-set\()/,P="-webkit-",_="-moz-",T="-ms-",N=59,L=125,E=123,R=40,F=41,D=10,$=13,M=32,z=45,B=42,G=44,W=58,H=47,q=126,U=107,Y=1,V=1,X=0,Z=1,J=1,K=1,Q=0,ee=0,te=0,re=[],ne=[],oe=0,ae=null,ie=0,se=1,ce="",le="",ue="";function pe(e,t,o,a,i){for(var s,c,u=0,p=0,d=0,h=0,v=0,b=0,y=0,x=0,k=0,j=0,S=0,A=0,O=0,I=0,_=0,T=0,Q=0,ne=0,ae=0,he=o.length,ye=he-1,xe="",we="",ke="",Ce="",je="",Se="";_<he;){if(y=o.charCodeAt(_),_===ye&&p+h+d+u!==0&&(0!==p&&(y=p===H?D:H),h=d=u=0,he++,ye++),p+h+d+u===0){if(_===ye&&(T>0&&(we=we.replace(n,"")),we.trim().length>0)){switch(y){case M:case 9:case N:case $:case D:break;default:we+=o.charAt(_)}y=N}if(1===Q)switch(y){case E:case L:case N:case 34:case 39:case R:case F:case G:Q=0;case 9:case $:case D:case M:break;default:for(Q=0,ae=_,v=y,_--,y=N;ae<he;)switch(o.charCodeAt(ae++)){case D:case $:case N:++_,y=v,ae=he;break;case W:T>0&&(++_,y=v);case E:ae=he}}switch(y){case E:for(v=(we=we.trim()).charCodeAt(0),S=1,ae=++_;_<he;){switch(y=o.charCodeAt(_)){case E:S++;break;case L:S--;break;case H:switch(b=o.charCodeAt(_+1)){case B:case H:_=be(b,_,ye,o)}break;case 91:y++;case R:y++;case 34:case 39:for(;_++<ye&&o.charCodeAt(_)!==y;);}if(0===S)break;_++}if(ke=o.substring(ae,_),0===v&&(v=(we=we.replace(r,"").trim()).charCodeAt(0)),64===v){switch(T>0&&(we=we.replace(n,"")),b=we.charCodeAt(1)){case 100:case 109:case 115:case z:s=t;break;default:s=re}if(ae=(ke=pe(t,s,ke,b,i+1)).length,te>0&&0===ae&&(ae=we.length),oe>0&&(c=ve(3,ke,s=de(re,we,ne),t,V,Y,ae,b,i,a),we=s.join(""),void 0!==c&&0===(ae=(ke=c.trim()).length)&&(b=0,ke="")),ae>0)switch(b){case 115:we=we.replace(C,ge);case 100:case 109:case z:ke=we+"{"+ke+"}";break;case U:ke=(we=we.replace(f,"$1 $2"+(se>0?ce:"")))+"{"+ke+"}",ke=1===J||2===J&&me("@"+ke,3)?"@"+P+ke+"@"+ke:"@"+ke;break;default:ke=we+ke,112===a&&(Ce+=ke,ke="")}else ke=""}else ke=pe(t,de(t,we,ne),ke,a,i+1);je+=ke,A=0,Q=0,I=0,T=0,ne=0,O=0,we="",ke="",y=o.charCodeAt(++_);break;case L:case N:if((ae=(we=(T>0?we.replace(n,""):we).trim()).length)>1)switch(0===I&&((v=we.charCodeAt(0))===z||v>96&&v<123)&&(ae=(we=we.replace(" ",":")).length),oe>0&&void 0!==(c=ve(1,we,t,e,V,Y,Ce.length,a,i,a))&&0===(ae=(we=c.trim()).length)&&(we="\0\0"),v=we.charCodeAt(0),b=we.charCodeAt(1),v){case 0:break;case 64:if(105===b||99===b){Se+=we+o.charAt(_);break}default:if(we.charCodeAt(ae-1)===W)break;Ce+=fe(we,v,b,we.charCodeAt(2))}A=0,Q=0,I=0,T=0,ne=0,we="",y=o.charCodeAt(++_)}}switch(y){case $:case D:if(p+h+d+u+ee===0)switch(j){case F:case 39:case 34:case 64:case q:case 62:case B:case 43:case H:case z:case W:case G:case N:case E:case L:break;default:I>0&&(Q=1)}p===H?p=0:Z+A===0&&a!==U&&we.length>0&&(T=1,we+="\0"),oe*ie>0&&ve(0,we,t,e,V,Y,Ce.length,a,i,a),Y=1,V++;break;case N:case L:if(p+h+d+u===0){Y++;break}default:switch(Y++,xe=o.charAt(_),y){case 9:case M:if(h+u+p===0)switch(x){case G:case W:case 9:case M:xe="";break;default:y!==M&&(xe=" ")}break;case 0:xe="\\0";break;case 12:xe="\\f";break;case 11:xe="\\v";break;case 38:h+p+u===0&&Z>0&&(ne=1,T=1,xe="\f"+xe);break;case 108:if(h+p+u+X===0&&I>0)switch(_-I){case 2:112===x&&o.charCodeAt(_-3)===W&&(X=x);case 8:111===k&&(X=k)}break;case W:h+p+u===0&&(I=_);break;case G:p+d+h+u===0&&(T=1,xe+="\r");break;case 34:case 39:0===p&&(h=h===y?0:0===h?y:h);break;case 91:h+p+d===0&&u++;break;case 93:h+p+d===0&&u--;break;case F:h+p+u===0&&d--;break;case R:h+p+u===0&&(0===A&&(2*x+3*k==533||(S=0,A=1)),d++);break;case 64:p+d+h+u+I+O===0&&(O=1);break;case B:case H:if(h+u+d>0)break;switch(p){case 0:switch(2*y+3*o.charCodeAt(_+1)){case 235:p=H;break;case 220:ae=_,p=B}break;case B:y===H&&x===B&&ae+2!==_&&(33===o.charCodeAt(ae+2)&&(Ce+=o.substring(ae,_+1)),xe="",p=0)}}if(0===p){if(Z+h+u+O===0&&a!==U&&y!==N)switch(y){case G:case q:case 62:case 43:case F:case R:if(0===A){switch(x){case 9:case M:case D:case $:xe+="\0";break;default:xe="\0"+xe+(y===G?"":"\0")}T=1}else switch(y){case R:I+7===_&&108===x&&(I=0),A=++S;break;case F:0==(A=--S)&&(T=1,xe+="\0")}break;case 9:case M:switch(x){case 0:case E:case L:case N:case G:case 12:case 9:case M:case D:case $:break;default:0===A&&(T=1,xe+="\0")}}we+=xe,y!==M&&9!==y&&(j=y)}}k=x,x=y,_++}if(ae=Ce.length,te>0&&0===ae&&0===je.length&&0===t[0].length==0&&(109!==a||1===t.length&&(Z>0?le:ue)===t[0])&&(ae=t.join(",").length+2),ae>0){if(s=0===Z&&a!==U?function(e){for(var t,r,o=0,a=e.length,i=Array(a);o<a;++o){for(var s=e[o].split(l),c="",u=0,p=0,d=0,h=0,f=s.length;u<f;++u)if(!(0===(p=(r=s[u]).length)&&f>1)){if(d=c.charCodeAt(c.length-1),h=r.charCodeAt(0),t="",0!==u)switch(d){case B:case q:case 62:case 43:case M:case R:break;default:t=" "}switch(h){case 38:r=t+le;case q:case 62:case 43:case M:case F:case R:break;case 91:r=t+r+le;break;case W:switch(2*r.charCodeAt(1)+3*r.charCodeAt(2)){case 530:if(K>0){r=t+r.substring(8,p-1);break}default:(u<1||s[u-1].length<1)&&(r=t+le+r)}break;case G:t="";default:r=p>1&&r.indexOf(":")>0?t+r.replace(w,"$1"+le+"$2"):t+r+le}c+=r}i[o]=c.replace(n,"").trim()}return i}(t):t,oe>0&&void 0!==(c=ve(2,Ce,s,e,V,Y,ae,a,i,a))&&0===(Ce=c).length)return Se+Ce+je;if(Ce=s.join(",")+"{"+Ce+"}",J*X!=0){switch(2!==J||me(Ce,2)||(X=0),X){case 111:Ce=Ce.replace(g,":-moz-$1")+Ce;break;case 112:Ce=Ce.replace(m,"::"+P+"input-$1")+Ce.replace(m,"::-moz-$1")+Ce.replace(m,":-ms-input-$1")+Ce}X=0}}return Se+Ce+je}function de(e,t,r){var n=t.trim().split(u),o=n,a=n.length,i=e.length;switch(i){case 0:case 1:for(var s=0,c=0===i?"":e[0]+" ";s<a;++s)o[s]=he(c,o[s],r,i).trim();break;default:s=0;var l=0;for(o=[];s<a;++s)for(var p=0;p<i;++p)o[l++]=he(e[p]+" ",n[s],r,i).trim()}return o}function he(e,t,r,n){var o=t,a=o.charCodeAt(0);switch(a<33&&(a=(o=o.trim()).charCodeAt(0)),a){case 38:switch(Z+n){case 0:case 1:if(0===e.trim().length)break;default:return o.replace(p,"$1"+e.trim())}break;case W:if(103!==o.charCodeAt(1))return e.trim()+o.replace(p,"$1"+e.trim());if(K>0&&Z>0)return o.replace(d,"$1").replace(p,"$1"+ue);default:if(r*Z>0&&o.indexOf("\f")>0)return o.replace(p,(e.charCodeAt(0)===W?"":"$1")+e.trim())}return e+o}function fe(e,t,r,n){var l,u=0,p=e+";",d=2*t+3*r+4*n;if(944===d)return function(e){var t=e.length,r=e.indexOf(":",9)+1,n=e.substring(0,r).trim(),o=e.substring(r,t-1).trim();switch(e.charCodeAt(9)*se){case 0:break;case z:if(110!==e.charCodeAt(10))break;default:var a=o.split((o="",s)),i=0;for(r=0,t=a.length;i<t;r=0,++i){for(var l=a[i],u=l.split(c);l=u[r];){var p=l.charCodeAt(0);if(1===se&&(p>64&&p<90||p>96&&p<123||95===p||p===z&&l.charCodeAt(1)!==z)&&isNaN(parseFloat(l))+(-1!==l.indexOf("("))===1)switch(l){case"infinite":case"alternate":case"backwards":case"running":case"normal":case"forwards":case"both":case"none":case"linear":case"ease":case"ease-in":case"ease-out":case"ease-in-out":case"paused":case"reverse":case"alternate-reverse":case"inherit":case"initial":case"unset":case"step-start":case"step-end":break;default:l+=ce}u[r++]=l}o+=(0===i?"":",")+u.join(" ")}}return o=n+o+";",1===J||2===J&&me(o,1)?P+o+o:o}(p);if(0===J||2===J&&!me(p,1))return p;switch(d){case 1015:return 97===p.charCodeAt(10)?P+p+p:p;case 951:return 116===p.charCodeAt(3)?P+p+p:p;case 963:return 110===p.charCodeAt(5)?P+p+p:p;case 1009:if(100!==p.charCodeAt(4))break;case 969:case 942:return P+p+p;case 978:return P+p+_+p+p;case 1019:case 983:return P+p+_+p+T+p+p;case 883:return p.charCodeAt(8)===z?P+p+p:p.indexOf("image-set(",11)>0?p.replace(I,"$1"+P+"$2")+p:p;case 932:if(p.charCodeAt(4)===z)switch(p.charCodeAt(5)){case 103:return P+"box-"+p.replace("-grow","")+P+p+T+p.replace("grow","positive")+p;case 115:return P+p+T+p.replace("shrink","negative")+p;case 98:return P+p+T+p.replace("basis","preferred-size")+p}return P+p+T+p+p;case 964:return P+p+T+"flex-"+p+p;case 1023:if(99!==p.charCodeAt(8))break;return l=p.substring(p.indexOf(":",15)).replace("flex-","").replace("space-between","justify"),P+"box-pack"+l+P+p+T+"flex-pack"+l+p;case 1005:return a.test(p)?p.replace(o,":"+P)+p.replace(o,":"+_)+p:p;case 1e3:switch(u=(l=p.substring(13).trim()).indexOf("-")+1,l.charCodeAt(0)+l.charCodeAt(u)){case 226:l=p.replace(k,"tb");break;case 232:l=p.replace(k,"tb-rl");break;case 220:l=p.replace(k,"lr");break;default:return p}return P+p+T+l+p;case 1017:if(-1===p.indexOf("sticky",9))return p;case 975:switch(u=(p=e).length-10,d=(l=(33===p.charCodeAt(u)?p.substring(0,u):p).substring(e.indexOf(":",7)+1).trim()).charCodeAt(0)+(0|l.charCodeAt(7))){case 203:if(l.charCodeAt(8)<111)break;case 115:p=p.replace(l,P+l)+";"+p;break;case 207:case 102:p=p.replace(l,P+(d>102?"inline-":"")+"box")+";"+p.replace(l,P+l)+";"+p.replace(l,T+l+"box")+";"+p}return p+";";case 938:if(p.charCodeAt(5)===z)switch(p.charCodeAt(6)){case 105:return l=p.replace("-items",""),P+p+P+"box-"+l+T+"flex-"+l+p;case 115:return P+p+T+"flex-item-"+p.replace(S,"")+p;default:return P+p+T+"flex-line-pack"+p.replace("align-content","").replace(S,"")+p}break;case 973:case 989:if(p.charCodeAt(3)!==z||122===p.charCodeAt(4))break;case 931:case 953:if(!0===O.test(e))return 115===(l=e.substring(e.indexOf(":")+1)).charCodeAt(0)?fe(e.replace("stretch","fill-available"),t,r,n).replace(":fill-available",":stretch"):p.replace(l,P+l)+p.replace(l,_+l.replace("fill-",""))+p;break;case 962:if(p=P+p+(102===p.charCodeAt(5)?T+p:"")+p,r+n===211&&105===p.charCodeAt(13)&&p.indexOf("transform",10)>0)return p.substring(0,p.indexOf(";",27)+1).replace(i,"$1"+P+"$2")+p}return p}function me(e,t){var r=e.indexOf(1===t?":":"{"),n=e.substring(0,3!==t?r:10),o=e.substring(r+1,e.length-1);return ae(2!==t?n:n.replace(A,"$1"),o,t)}function ge(e,t){var r=fe(t,t.charCodeAt(0),t.charCodeAt(1),t.charCodeAt(2));return r!==t+";"?r.replace(j," or ($1)").substring(4):"("+t+")"}function ve(e,t,r,n,o,a,i,s,c,l){for(var u,p=0,d=t;p<oe;++p)switch(u=ne[p].call(xe,e,d,r,n,o,a,i,s,c,l)){case void 0:case!1:case!0:case null:break;default:d=u}if(d!==t)return d}function be(e,t,r,n){for(var o=t+1;o<r;++o)switch(n.charCodeAt(o)){case H:if(e===B&&n.charCodeAt(o-1)===B&&t+2!==o)return o+1;break;case D:if(e===H)return o+1}return o}function ye(e){for(var t in e){var r=e[t];switch(t){case"keyframe":se=0|r;break;case"global":K=0|r;break;case"cascade":Z=0|r;break;case"compress":Q=0|r;break;case"semicolon":ee=0|r;break;case"preserve":te=0|r;break;case"prefix":ae=null,r?"function"!=typeof r?J=1:(J=2,ae=r):J=0}}return ye}function xe(t,r){if(void 0!==this&&this.constructor===xe)return e(t);var o=t,a=o.charCodeAt(0);a<33&&(a=(o=o.trim()).charCodeAt(0)),se>0&&(ce=o.replace(h,91===a?"":"-")),a=1,1===Z?ue=o:le=o;var i,s=[ue];oe>0&&void 0!==(i=ve(-1,r,s,s,V,Y,0,0,0,0))&&"string"==typeof i&&(r=i);var c=pe(re,s,r,0,0);return oe>0&&void 0!==(i=ve(-2,c,s,s,V,Y,c.length,0,0,0))&&"string"!=typeof(c=i)&&(a=0),ce="",ue="",le="",X=0,V=1,Y=1,Q*a==0?c:c.replace(n,"").replace(v,"").replace(b,"$1").replace(y,"$1").replace(x," ")}return xe.use=function e(t){switch(t){case void 0:case null:oe=ne.length=0;break;default:if("function"==typeof t)ne[oe++]=t;else if("object"==typeof t)for(var r=0,n=t.length;r<n;++r)e(t[r]);else ie=0|!!t}return e},xe.set=ye,void 0!==t&&ye(t),xe}(null)},942:(e,t)=>{var r;!function(){"use strict";var n={}.hasOwnProperty;function o(){for(var e="",t=0;t<arguments.length;t++){var r=arguments[t];r&&(e=i(e,a(r)))}return e}function a(e){if("string"==typeof e||"number"==typeof e)return e;if("object"!=typeof e)return"";if(Array.isArray(e))return o.apply(null,e);if(e.toString!==Object.prototype.toString&&!e.toString.toString().includes("[native code]"))return e.toString();var t="";for(var r in e)n.call(e,r)&&e[r]&&(t=i(t,r));return t}function i(e,t){return t?e?e+" "+t:e+t:e}e.exports?(o.default=o,e.exports=o):void 0===(r=function(){return o}.apply(t,[]))||(e.exports=r)}()}},t={};function r(n){var o=t[n];if(void 0!==o)return o.exports;var a=t[n]={exports:{}};return e[n](a,a.exports,r),a.exports}r.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return r.d(t,{a:t}),t},r.d=(e,t)=>{for(var n in t)r.o(t,n)&&!r.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},r.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r.nc=void 0,(()=>{"use strict";var e=r(79),t=r.n(e),n=r(162),o=r.n(n);const a=window.React;var i=r.n(a);const s={animationIterationCount:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1};var c=r(467),l=Number.isNaN||function(e){return"number"==typeof e&&e!=e};function u(e,t){if(e.length!==t.length)return!1;for(var r=0;r<e.length;r++)if(!((n=e[r])===(o=t[r])||l(n)&&l(o)))return!1;var n,o;return!0}const p=function(e,t){var r;void 0===t&&(t=u);var n,o=[],a=!1;return function(){for(var i=[],s=0;s<arguments.length;s++)i[s]=arguments[s];return a&&r===this&&t(i,o)||(n=e.apply(this,i),a=!0,r=this,o=i),n}};var d=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|inert|itemProp|itemScope|itemType|itemID|itemRef|on|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;const h=(f={},function(e){return void 0===f[e]&&(f[e]=(t=e,d.test(t)||111===t.charCodeAt(0)&&110===t.charCodeAt(1)&&t.charCodeAt(2)<91)),f[e];var t});var f;function m(e){return Object.prototype.toString.call(e).slice(8,-1)}function g(e){return"Object"===m(e)&&e.constructor===Object&&Object.getPrototypeOf(e)===Object.prototype}function v(e){return"Array"===m(e)}function b(e){return"Symbol"===m(e)}function y(){for(var e=0,t=0,r=arguments.length;t<r;t++)e+=arguments[t].length;var n=Array(e),o=0;for(t=0;t<r;t++)for(var a=arguments[t],i=0,s=a.length;i<s;i++,o++)n[o]=a[i];return n}function x(e,t,r,n){var o=n.propertyIsEnumerable(t)?"enumerable":"nonenumerable";"enumerable"===o&&(e[t]=r),"nonenumerable"===o&&Object.defineProperty(e,t,{value:r,enumerable:!1,writable:!0,configurable:!0})}function w(e,t,r){if(!g(t))return r&&v(r)&&r.forEach((function(r){t=r(e,t)})),t;var n={};return g(e)&&(n=y(Object.getOwnPropertyNames(e),Object.getOwnPropertySymbols(e)).reduce((function(r,n){var o=e[n];return(!b(n)&&!Object.getOwnPropertyNames(t).includes(n)||b(n)&&!Object.getOwnPropertySymbols(t).includes(n))&&x(r,n,o,e),r}),{})),y(Object.getOwnPropertyNames(t),Object.getOwnPropertySymbols(t)).reduce((function(n,o){var a=t[o],i=g(e)?e[o]:void 0;return r&&v(r)&&r.forEach((function(e){a=e(i,a)})),void 0!==i&&g(a)&&(a=w(i,a,r)),x(n,o,a,t),n}),n)}const k=function(e){for(var t=[],r=1;r<arguments.length;r++)t[r-1]=arguments[r];var n=null,o=e;return g(e)&&e.extensions&&1===Object.keys(e).length&&(o={},n=e.extensions),t.reduce((function(e,t){return w(e,t,n)}),o)};var C=function(e,t){for(var r=[e[0]],n=0,o=t.length;n<o;n+=1)r.push(t[n],e[n+1]);return r},j="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},S=function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")},A=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),O=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},I=function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)},P=function(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t},_=function(e){return"object"===(void 0===e?"undefined":j(e))&&e.constructor===Object},T=Object.freeze([]),N=Object.freeze({});function L(e){return"function"==typeof e}function E(e){return e.displayName||e.name||"Component"}function R(e){return e&&"string"==typeof e.styledComponentId}var F="undefined"!=typeof process&&(process.env.REACT_APP_SC_ATTR||process.env.SC_ATTR)||"data-styled",D="data-styled-version",$="undefined"!=typeof window&&"HTMLElement"in window,M="boolean"==typeof SC_DISABLE_SPEEDY&&SC_DISABLE_SPEEDY||"undefined"!=typeof process&&(process.env.REACT_APP_SC_DISABLE_SPEEDY||process.env.SC_DISABLE_SPEEDY)||!1,z=function(e){function t(r){S(this,t);for(var n=arguments.length,o=Array(n>1?n-1:0),a=1;a<n;a++)o[a-1]=arguments[a];var i=P(this,e.call(this,"An error occurred. See https://github.com/styled-components/styled-components/blob/master/packages/styled-components/src/utils/errors.md#"+r+" for more information."+(o.length>0?" Additional arguments: "+o.join(", "):"")));return P(i)}return I(t,e),t}(Error),B=/^[^\S\n]*?\/\* sc-component-id:\s*(\S+)\s+\*\//gm,G=function(e){var t=""+(e||""),r=[];return t.replace(B,(function(e,t,n){return r.push({componentId:t,matchIndex:n}),e})),r.map((function(e,n){var o=e.componentId,a=e.matchIndex,i=r[n+1];return{componentId:o,cssFromDOM:i?t.slice(a,i.matchIndex):t.slice(a)}}))},W=/^\s*\/\/.*$/gm,H=new(t())({global:!1,cascade:!0,keyframe:!1,prefix:!1,compress:!1,semicolon:!0}),q=new(t())({global:!1,cascade:!0,keyframe:!1,prefix:!0,compress:!1,semicolon:!1}),U=[],Y=function(e){if(-2===e){var t=U;return U=[],t}},V=o()((function(e){U.push(e)})),X=void 0,Z=void 0,J=void 0,K=function(e,t,r){return t>0&&-1!==r.slice(0,t).indexOf(Z)&&r.slice(t-Z.length,t)!==Z?"."+X:e};q.use([function(e,t,r){2===e&&r.length&&r[0].lastIndexOf(Z)>0&&(r[0]=r[0].replace(J,K))},V,Y]),H.use([V,Y]);var Q=function(e){return H("",e)};function ee(e,t,r){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"&",o=e.join("").replace(W,""),a=t&&r?r+" "+t+" { "+o+" }":o;return X=n,Z=t,J=new RegExp("\\"+Z+"\\b","g"),q(r||!t?"":t,a)}var te,re=function(){return r.nc},ne=function(e,t,r){r&&((e[t]||(e[t]=Object.create(null)))[r]=!0)},oe=function(e,t){e[t]=Object.create(null)},ae=function(e){return function(t,r){return void 0!==e[t]&&e[t][r]}},ie=function(e){var t="";for(var r in e)t+=Object.keys(e[r]).join(" ")+" ";return t.trim()},se=function(e){if(e.sheet)return e.sheet;for(var t=e.ownerDocument.styleSheets.length,r=0;r<t;r+=1){var n=e.ownerDocument.styleSheets[r];if(n.ownerNode===e)return n}throw new z(10)},ce=function(e,t,r){if(!t)return!1;var n=e.cssRules.length;try{e.insertRule(t,r<=n?r:n)}catch(e){return!1}return!0},le=function(e){return"\n/* sc-component-id: "+e+" */\n"},ue=function(e,t){for(var r=0,n=0;n<=t;n+=1)r+=e[n];return r},pe=function(e,t){return function(r){var n=re();return"<style "+[n&&'nonce="'+n+'"',F+'="'+ie(t)+'"',D+'="4.4.1"',r].filter(Boolean).join(" ")+">"+e()+"</style>"}},de=function(e,t){return function(){var r,n=((r={})[F]=ie(t),r[D]="4.4.1",r),o=re();return o&&(n.nonce=o),i().createElement("style",O({},n,{dangerouslySetInnerHTML:{__html:e()}}))}},he=function(e){return function(){return Object.keys(e)}},fe=function(e,t){return e.createTextNode(le(t))},me=function e(t,r){var n=void 0===t?Object.create(null):t,o=void 0===r?Object.create(null):r,a=function(e){var t=o[e];return void 0!==t?t:o[e]=[""]},i=function(){var e="";for(var t in o){var r=o[t][0];r&&(e+=le(t)+r)}return e};return{clone:function(){var t=function(e){var t=Object.create(null);for(var r in e)t[r]=O({},e[r]);return t}(n),r=Object.create(null);for(var a in o)r[a]=[o[a][0]];return e(t,r)},css:i,getIds:he(o),hasNameForId:ae(n),insertMarker:a,insertRules:function(e,t,r){a(e)[0]+=t.join(" "),ne(n,e,r)},removeRules:function(e){var t=o[e];void 0!==t&&(t[0]="",oe(n,e))},sealed:!1,styleTag:null,toElement:de(i,n),toHTML:pe(i,n)}},ge=function(e,t,r,n,o){if($&&!r){var a=function(e,t,r){var n=document;e?n=e.ownerDocument:t&&(n=t.ownerDocument);var o=n.createElement("style");o.setAttribute(F,""),o.setAttribute(D,"4.4.1");var a=re();if(a&&o.setAttribute("nonce",a),o.appendChild(n.createTextNode("")),e&&!t)e.appendChild(o);else{if(!t||!e||!t.parentNode)throw new z(6);t.parentNode.insertBefore(o,r?t:t.nextSibling)}return o}(e,t,n);return M?function(e,t){var r=Object.create(null),n=Object.create(null),o=void 0!==t,a=!1,i=function(t){var o=n[t];return void 0!==o?o:(n[t]=fe(e.ownerDocument,t),e.appendChild(n[t]),r[t]=Object.create(null),n[t])},s=function(){var e="";for(var t in n)e+=n[t].data;return e};return{clone:function(){throw new z(5)},css:s,getIds:he(n),hasNameForId:ae(r),insertMarker:i,insertRules:function(e,n,s){for(var c=i(e),l=[],u=n.length,p=0;p<u;p+=1){var d=n[p],h=o;if(h&&-1!==d.indexOf("@import"))l.push(d);else{h=!1;var f=p===u-1?"":" ";c.appendData(""+d+f)}}ne(r,e,s),o&&l.length>0&&(a=!0,t().insertRules(e+"-import",l))},removeRules:function(i){var s=n[i];if(void 0!==s){var c=fe(e.ownerDocument,i);e.replaceChild(c,s),n[i]=c,oe(r,i),o&&a&&t().removeRules(i+"-import")}},sealed:!1,styleTag:e,toElement:de(s,r),toHTML:pe(s,r)}}(a,o):function(e,t){var r=Object.create(null),n=Object.create(null),o=[],a=void 0!==t,i=!1,s=function(e){var t=n[e];return void 0!==t?t:(n[e]=o.length,o.push(0),oe(r,e),n[e])},c=function(){var t=se(e).cssRules,r="";for(var a in n){r+=le(a);for(var i=n[a],s=ue(o,i),c=s-o[i];c<s;c+=1){var l=t[c];void 0!==l&&(r+=l.cssText)}}return r};return{clone:function(){throw new z(5)},css:c,getIds:he(n),hasNameForId:ae(r),insertMarker:s,insertRules:function(n,c,l){for(var u=s(n),p=se(e),d=ue(o,u),h=0,f=[],m=c.length,g=0;g<m;g+=1){var v=c[g],b=a;b&&-1!==v.indexOf("@import")?f.push(v):ce(p,v,d+h)&&(b=!1,h+=1)}a&&f.length>0&&(i=!0,t().insertRules(n+"-import",f)),o[u]+=h,ne(r,n,l)},removeRules:function(s){var c=n[s];if(void 0!==c&&!1!==e.isConnected){var l=o[c];!function(e,t,r){for(var n=t-r,o=t;o>n;o-=1)e.deleteRule(o)}(se(e),ue(o,c)-1,l),o[c]=0,oe(r,s),a&&i&&t().removeRules(s+"-import")}},sealed:!1,styleTag:e,toElement:de(c,r),toHTML:pe(c,r)}}(a,o)}return me()},ve=/\s+/;te=$?M?40:1e3:-1;var be=0,ye=void 0,xe=function(){function e(){var t=this,r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:$?document.head:null,n=arguments.length>1&&void 0!==arguments[1]&&arguments[1];S(this,e),this.getImportRuleTag=function(){var e=t.importRuleTag;if(void 0!==e)return e;var r=t.tags[0];return t.importRuleTag=ge(t.target,r?r.styleTag:null,t.forceServer,!0)},be+=1,this.id=be,this.forceServer=n,this.target=n?null:r,this.tagMap={},this.deferred={},this.rehydratedNames={},this.ignoreRehydratedNames={},this.tags=[],this.capacity=1,this.clones=[]}return e.prototype.rehydrate=function(){if(!$||this.forceServer)return this;var e=[],t=[],r=!1,n=document.querySelectorAll("style["+F+"]["+D+'="4.4.1"]'),o=n.length;if(!o)return this;for(var a=0;a<o;a+=1){var i=n[a];r||(r=!!i.getAttribute("data-styled-streamed"));for(var s,c=(i.getAttribute(F)||"").trim().split(ve),l=c.length,u=0;u<l;u+=1)s=c[u],this.rehydratedNames[s]=!0;t.push.apply(t,G(i.textContent)),e.push(i)}var p=t.length;if(!p)return this;var d=this.makeTag(null);!function(e,t,r){for(var n=0,o=r.length;n<o;n+=1){var a=r[n],i=a.componentId,s=a.cssFromDOM,c=Q(s);e.insertRules(i,c)}for(var l=0,u=t.length;l<u;l+=1){var p=t[l];p.parentNode&&p.parentNode.removeChild(p)}}(d,e,t),this.capacity=Math.max(1,te-p),this.tags.push(d);for(var h=0;h<p;h+=1)this.tagMap[t[h].componentId]=d;return this},e.reset=function(){ye=new e(void 0,arguments.length>0&&void 0!==arguments[0]&&arguments[0]).rehydrate()},e.prototype.clone=function(){var t=new e(this.target,this.forceServer);return this.clones.push(t),t.tags=this.tags.map((function(e){for(var r=e.getIds(),n=e.clone(),o=0;o<r.length;o+=1)t.tagMap[r[o]]=n;return n})),t.rehydratedNames=O({},this.rehydratedNames),t.deferred=O({},this.deferred),t},e.prototype.sealAllTags=function(){this.capacity=1,this.tags.forEach((function(e){e.sealed=!0}))},e.prototype.makeTag=function(e){var t=e?e.styleTag:null;return ge(this.target,t,this.forceServer,!1,this.getImportRuleTag)},e.prototype.getTagForId=function(e){var t=this.tagMap[e];if(void 0!==t&&!t.sealed)return t;var r=this.tags[this.tags.length-1];return this.capacity-=1,0===this.capacity&&(this.capacity=te,r=this.makeTag(r),this.tags.push(r)),this.tagMap[e]=r},e.prototype.hasId=function(e){return void 0!==this.tagMap[e]},e.prototype.hasNameForId=function(e,t){if(void 0===this.ignoreRehydratedNames[e]&&this.rehydratedNames[t])return!0;var r=this.tagMap[e];return void 0!==r&&r.hasNameForId(e,t)},e.prototype.deferredInject=function(e,t){if(void 0===this.tagMap[e]){for(var r=this.clones,n=0;n<r.length;n+=1)r[n].deferredInject(e,t);this.getTagForId(e).insertMarker(e),this.deferred[e]=t}},e.prototype.inject=function(e,t,r){for(var n=this.clones,o=0;o<n.length;o+=1)n[o].inject(e,t,r);var a=this.getTagForId(e);if(void 0!==this.deferred[e]){var i=this.deferred[e].concat(t);a.insertRules(e,i,r),this.deferred[e]=void 0}else a.insertRules(e,t,r)},e.prototype.remove=function(e){var t=this.tagMap[e];if(void 0!==t){for(var r=this.clones,n=0;n<r.length;n+=1)r[n].remove(e);t.removeRules(e),this.ignoreRehydratedNames[e]=!0,this.deferred[e]=void 0}},e.prototype.toHTML=function(){return this.tags.map((function(e){return e.toHTML()})).join("")},e.prototype.toReactElements=function(){var e=this.id;return this.tags.map((function(t,r){var n="sc-"+e+"-"+r;return(0,a.cloneElement)(t.toElement(),{key:n})}))},A(e,null,[{key:"master",get:function(){return ye||(ye=(new e).rehydrate())}},{key:"instance",get:function(){return e.master}}]),e}(),we=function(){function e(t,r){var n=this;S(this,e),this.inject=function(e){e.hasNameForId(n.id,n.name)||e.inject(n.id,n.rules,n.name)},this.toString=function(){throw new z(12,String(n.name))},this.name=t,this.rules=r,this.id="sc-keyframes-"+t}return e.prototype.getName=function(){return this.name},e}(),ke=/([A-Z])/g,Ce=/^ms-/;function je(e){return e.replace(ke,"-$1").toLowerCase().replace(Ce,"-ms-")}var Se=function(e){return null==e||!1===e||""===e},Ae=function e(t,r){var n=[];return Object.keys(t).forEach((function(r){if(!Se(t[r])){if(_(t[r]))return n.push.apply(n,e(t[r],r)),n;if(L(t[r]))return n.push(je(r)+":",t[r],";"),n;n.push(je(r)+": "+(o=r,(null==(a=t[r])||"boolean"==typeof a||""===a?"":"number"!=typeof a||0===a||o in s?String(a).trim():a+"px")+";"))}var o,a;return n})),r?[r+" {"].concat(n,["}"]):n};function Oe(e,t,r){if(Array.isArray(e)){for(var n,o=[],a=0,i=e.length;a<i;a+=1)null!==(n=Oe(e[a],t,r))&&(Array.isArray(n)?o.push.apply(o,n):o.push(n));return o}return Se(e)?null:R(e)?"."+e.styledComponentId:L(e)?"function"!=typeof(s=e)||s.prototype&&s.prototype.isReactComponent||!t?e:Oe(e(t),t,r):e instanceof we?r?(e.inject(r),e.getName()):e:_(e)?Ae(e):e.toString();var s}function Ie(e){for(var t=arguments.length,r=Array(t>1?t-1:0),n=1;n<t;n++)r[n-1]=arguments[n];return L(e)||_(e)?Oe(C(T,[e].concat(r))):Oe(C(e,r))}function Pe(e,t){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:N;if(!(0,c.isValidElementType)(t))throw new z(1,String(t));var n=function(){return e(t,r,Ie.apply(void 0,arguments))};return n.withConfig=function(n){return Pe(e,t,O({},r,n))},n.attrs=function(n){return Pe(e,t,O({},r,{attrs:Array.prototype.concat(r.attrs,n).filter(Boolean)}))},n}function _e(e){for(var t,r=0|e.length,n=0|r,o=0;r>=4;)t=1540483477*(65535&(t=255&e.charCodeAt(o)|(255&e.charCodeAt(++o))<<8|(255&e.charCodeAt(++o))<<16|(255&e.charCodeAt(++o))<<24))+((1540483477*(t>>>16)&65535)<<16),n=1540483477*(65535&n)+((1540483477*(n>>>16)&65535)<<16)^(t=1540483477*(65535&(t^=t>>>24))+((1540483477*(t>>>16)&65535)<<16)),r-=4,++o;switch(r){case 3:n^=(255&e.charCodeAt(o+2))<<16;case 2:n^=(255&e.charCodeAt(o+1))<<8;case 1:n=1540483477*(65535&(n^=255&e.charCodeAt(o)))+((1540483477*(n>>>16)&65535)<<16)}return((n=1540483477*(65535&(n^=n>>>13))+((1540483477*(n>>>16)&65535)<<16))^n>>>15)>>>0}var Te=function(e){return String.fromCharCode(e+(e>25?39:97))};function Ne(e){var t="",r=void 0;for(r=e;r>52;r=Math.floor(r/52))t=Te(r%52)+t;return Te(r%52)+t}function Le(e,t){for(var r=0;r<e.length;r+=1){var n=e[r];if(Array.isArray(n)&&!Le(n,t))return!1;if(L(n)&&!R(n))return!1}return!t.some((function(e){return L(e)||function(e){for(var t in e)if(L(e[t]))return!0;return!1}(e)}))}var Ee,Re=function(e){return Ne(_e(e))},Fe=function(){function e(t,r,n){S(this,e),this.rules=t,this.isStatic=Le(t,r),this.componentId=n,xe.master.hasId(n)||xe.master.deferredInject(n,[])}return e.prototype.generateAndInjectStyles=function(e,t){var r=this.isStatic,n=this.componentId,o=this.lastClassName;if($&&r&&"string"==typeof o&&t.hasNameForId(n,o))return o;var a=Oe(this.rules,e,t),i=Re(this.componentId+a.join(""));return t.hasNameForId(n,i)||t.inject(this.componentId,ee(a,"."+i,void 0,n),i),this.lastClassName=i,i},e.generateName=function(e){return Re(e)},e}(),De=/[[\].#*$><+~=|^:(),"'`-]+/g,Me=/(^-|-$)/g;function ze(e){return e.replace(De,"-").replace(Me,"")}function Be(e){return"string"==typeof e&&!0}var Ge={childContextTypes:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDerivedStateFromProps:!0,propTypes:!0,type:!0},We={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},He=((Ee={})[c.ForwardRef]={$$typeof:!0,render:!0},Ee),qe=Object.defineProperty,Ue=Object.getOwnPropertyNames,Ye=Object.getOwnPropertySymbols,Ve=void 0===Ye?function(){return[]}:Ye,Xe=Object.getOwnPropertyDescriptor,Ze=Object.getPrototypeOf,Je=Object.prototype,Ke=Array.prototype;function Qe(e,t,r){if("string"!=typeof t){var n=Ze(t);n&&n!==Je&&Qe(e,n,r);for(var o=Ke.concat(Ue(t),Ve(t)),a=He[e.$$typeof]||Ge,i=He[t.$$typeof]||Ge,s=o.length,c=void 0,l=void 0;s--;)if(l=o[s],!(We[l]||r&&r[l]||i&&i[l]||a&&a[l])&&(c=Xe(t,l)))try{qe(e,l,c)}catch(e){}return e}return e}var et=(0,a.createContext)(),tt=et.Consumer,rt=(function(e){function t(r){S(this,t);var n=P(this,e.call(this,r));return n.getContext=p(n.getContext.bind(n)),n.renderInner=n.renderInner.bind(n),n}I(t,e),t.prototype.render=function(){return this.props.children?i().createElement(et.Consumer,null,this.renderInner):null},t.prototype.renderInner=function(e){var t=this.getContext(this.props.theme,e);return i().createElement(et.Provider,{value:t},this.props.children)},t.prototype.getTheme=function(e,t){if(L(e))return e(t);if(null===e||Array.isArray(e)||"object"!==(void 0===e?"undefined":j(e)))throw new z(8);return O({},t,e)},t.prototype.getContext=function(e,t){return this.getTheme(e,t)}}(a.Component),function(){function e(){S(this,e),this.masterSheet=xe.master,this.instance=this.masterSheet.clone(),this.sealed=!1}e.prototype.seal=function(){if(!this.sealed){var e=this.masterSheet.clones.indexOf(this.instance);this.masterSheet.clones.splice(e,1),this.sealed=!0}},e.prototype.collectStyles=function(e){if(this.sealed)throw new z(2);return i().createElement(ot,{sheet:this.instance},e)},e.prototype.getStyleTags=function(){return this.seal(),this.instance.toHTML()},e.prototype.getStyleElement=function(){return this.seal(),this.instance.toReactElements()},e.prototype.interleaveWithNodeStream=function(e){throw new z(3)}}(),(0,a.createContext)()),nt=rt.Consumer,ot=function(e){function t(r){S(this,t);var n=P(this,e.call(this,r));return n.getContext=p(n.getContext),n}return I(t,e),t.prototype.getContext=function(e,t){if(e)return e;if(t)return new xe(t);throw new z(4)},t.prototype.render=function(){var e=this.props,t=e.children,r=e.sheet,n=e.target;return i().createElement(rt.Provider,{value:this.getContext(r,n)},t)},t}(a.Component),at={},it=function(e){function t(){S(this,t);var r=P(this,e.call(this));return r.attrs={},r.renderOuter=r.renderOuter.bind(r),r.renderInner=r.renderInner.bind(r),r}return I(t,e),t.prototype.render=function(){return i().createElement(nt,null,this.renderOuter)},t.prototype.renderOuter=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:xe.master;return this.styleSheet=e,this.props.forwardedComponent.componentStyle.isStatic?this.renderInner():i().createElement(tt,null,this.renderInner)},t.prototype.renderInner=function(e){var t,r=this.props.forwardedComponent,n=r.componentStyle,o=r.defaultProps,i=(r.displayName,r.foldedComponentIds),s=r.styledComponentId,c=r.target;t=n.isStatic?this.generateAndInjectStyles(N,this.props):this.generateAndInjectStyles(function(e,t){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:N,n=!!r&&e.theme===r.theme;return e.theme&&!n?e.theme:t||r.theme}(this.props,e,o)||N,this.props);var l=this.props.as||this.attrs.as||c,u=Be(l),p={},d=O({},this.props,this.attrs),f=void 0;for(f in d)"forwardedComponent"!==f&&"as"!==f&&("forwardedRef"===f?p.ref=d[f]:"forwardedAs"===f?p.as=d[f]:u&&!h(f)||(p[f]=d[f]));return this.props.style&&this.attrs.style&&(p.style=O({},this.attrs.style,this.props.style)),p.className=Array.prototype.concat(i,s,t!==s?t:null,this.props.className,this.attrs.className).filter(Boolean).join(" "),(0,a.createElement)(l,p)},t.prototype.buildExecutionContext=function(e,t,r){var n=this,o=O({},t,{theme:e});return r.length?(this.attrs={},r.forEach((function(e){var t,r=e,a=!1,i=void 0,s=void 0;for(s in L(r)&&(r=r(o),a=!0),r)i=r[s],a||!L(i)||(t=i)&&t.prototype&&t.prototype.isReactComponent||R(i)||(i=i(o)),n.attrs[s]=i,o[s]=i})),o):o},t.prototype.generateAndInjectStyles=function(e,t){var r=t.forwardedComponent,n=r.attrs,o=r.componentStyle;return r.warnTooManyClasses,o.isStatic&&!n.length?o.generateAndInjectStyles(N,this.styleSheet):o.generateAndInjectStyles(this.buildExecutionContext(e,t,n),this.styleSheet)},t}(a.Component);function st(e,t,r){var n=R(e),o=!Be(e),a=t.displayName,s=void 0===a?function(e){return Be(e)?"styled."+e:"Styled("+E(e)+")"}(e):a,c=t.componentId,l=void 0===c?function(e,t,r){var n="string"!=typeof t?"sc":ze(t),o=(at[n]||0)+1;at[n]=o;var a=n+"-"+e.generateName(n+o);return r?r+"-"+a:a}(Fe,t.displayName,t.parentComponentId):c,u=t.ParentComponent,p=void 0===u?it:u,d=t.attrs,h=void 0===d?T:d,f=t.displayName&&t.componentId?ze(t.displayName)+"-"+t.componentId:t.componentId||l,m=n&&e.attrs?Array.prototype.concat(e.attrs,h).filter(Boolean):h,g=new Fe(n?e.componentStyle.rules.concat(r):r,m,f),v=void 0,b=function(e,t){return i().createElement(p,O({},e,{forwardedComponent:v,forwardedRef:t}))};return b.displayName=s,(v=i().forwardRef(b)).displayName=s,v.attrs=m,v.componentStyle=g,v.foldedComponentIds=n?Array.prototype.concat(e.foldedComponentIds,e.styledComponentId):T,v.styledComponentId=f,v.target=n?e.target:e,v.withComponent=function(e){var n=t.componentId,o=function(e,t){var r={};for(var n in e)t.indexOf(n)>=0||Object.prototype.hasOwnProperty.call(e,n)&&(r[n]=e[n]);return r}(t,["componentId"]),a=n&&n+"-"+(Be(e)?e:ze(E(e)));return st(e,O({},o,{attrs:m,componentId:a,ParentComponent:p}),r)},Object.defineProperty(v,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(t){this._foldedDefaultProps=n?k(e.defaultProps,t):t}}),v.toString=function(){return"."+v.styledComponentId},o&&Qe(v,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,styledComponentId:!0,target:!0,withComponent:!0}),v}var ct=function(e){return Pe(st,e)};function lt(e){for(var t=arguments.length,r=Array(t>1?t-1:0),n=1;n<t;n++)r[n-1]=arguments[n];var o=Ie.apply(void 0,[e].concat(r)),a=Ne(_e(JSON.stringify(o).replace(/\s|\\n/g,"")));return new we(a,ee(o,a,"@keyframes"))}["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"].forEach((function(e){ct[e]=ct(e)})),function(){function e(t,r){S(this,e),this.rules=t,this.componentId=r,this.isStatic=Le(t,T),xe.master.hasId(r)||xe.master.deferredInject(r,[])}e.prototype.createStyles=function(e,t){var r=ee(Oe(this.rules,e,t),"");t.inject(this.componentId,r)},e.prototype.removeStyles=function(e){var t=this.componentId;e.hasId(t)&&e.remove(t)},e.prototype.renderStyles=function(e,t){this.removeStyles(t),this.createStyles(e,t)}}(),$&&(window.scCGSHMRCache={});const ut=ct,pt=React.createContext(),dt=(pt.Provider,pt.Consumer,pt);r(452);const{apiFetch:ht}=wp,{__}=wp.i18n;async function ft(e,t=!0,r="template"){return await ht({path:"/agwp/v1/mark_favorite",method:"post",data:{id:e,favorite:t,type:r}}).then((e=>e))}const mt=React.createContext(),gt=(mt.Provider,mt.Consumer,{accent:"var(--ang-primary)",textLight:"var(--ang-sec-text)",textDark:"var(--ang-main-text)",lightGray:"#F2F2F2"}),vt=mt,bt=window.ReactJSXRuntime,{__:yt}=wp.i18n,{TabPanel:xt}=wp.components,wt=[{key:"blocks",label:AGWP.isContainer?yt("Templates","ang"):yt("Blocks","ang")},{key:"templates",label:yt("Templates","ang")}],kt=()=>{const e=React.useContext(dt),t=t=>{let r=(t=>{let r=e.state[t];return"templates"===t&&(r=e.state.archive),"blocks"===t&&(r=e.state.blockArchive),!!r&&r.length})(t.key),n=r>0?"("+r+")":"";return`${t.label} ${n}`};return(0,bt.jsx)("span",{id:"sk-library-tab",children:(0,bt.jsx)(xt,{className:"ang-nav",onSelect:t=>{e.dispatch({tab:t})},tabs:(r=wt,r.map((e=>({name:e.key,title:t(e),className:`tab-${e.key}`})))),children:e=>null})});var r};var Ct=r(942),jt=r.n(Ct);const St=()=>(0,bt.jsx)("svg",{width:"10",height:"9",viewBox:"0 0 10 9",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,bt.jsx)("path",{d:"M6.27486 4.5L8.8619 1.95916C9.17937 1.64736 9.17937 1.14184 8.8619 0.829785L8.28695 0.265098C7.96948 -0.0466992 7.45476 -0.0466992 7.13704 0.265098L4.55 2.80594L1.96296 0.265098C1.6455 -0.0466992 1.13078 -0.0466992 0.813054 0.265098L0.238099 0.829785C-0.0793665 1.14158 -0.0793665 1.64711 0.238099 1.95916L2.82514 4.5L0.238099 7.04084C-0.0793665 7.35264 -0.0793665 7.85816 0.238099 8.17021L0.813054 8.7349C1.13052 9.0467 1.6455 9.0467 1.96296 8.7349L4.55 6.19406L7.13704 8.7349C7.4545 9.0467 7.96948 9.0467 8.28695 8.7349L8.8619 8.17021C9.17937 7.85842 9.17937 7.35289 8.8619 7.04084L6.27486 4.5Z"})}),At=()=>(0,bt.jsx)("svg",{height:"16",width:"12",viewBox:"0 0 12 16",children:(0,bt.jsx)("path",{fillRule:"evenodd",d:"M5.05.01c.81 2.17.41 3.38-.52 4.31C3.55 5.37 1.98 6.15.9 7.68c-1.45 2.05-1.7 6.53 3.53 7.7-2.2-1.16-2.67-4.52-.3-6.61-.61 2.03.53 3.33 1.94 2.86 1.39-.47 2.3.53 2.27 1.67-.02.78-.31 1.44-1.13 1.81 3.42-.59 4.78-3.42 4.78-5.56 0-2.84-2.53-3.22-1.25-5.61-1.52.13-2.03 1.13-1.89 2.75.09 1.08-1.02 1.8-1.86 1.33-.67-.41-.66-1.19-.06-1.78C8.18 5.01 8.68 2.15 5.05.02L5.03 0l.02.01z"})}),Ot=()=>(0,bt.jsx)("svg",{height:"16",width:"16",viewBox:"0 0 16 16",children:(0,bt.jsx)("path",{fillRule:"evenodd",d:"M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 0 0 0 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 0 0 .01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"})}),It=()=>(0,bt.jsx)("svg",{height:"16",width:"12",viewBox:"0 0 12 16",children:(0,bt.jsx)("path",{fillRule:"evenodd",d:"M12 5.5l-8 8-4-4L1.5 8 4 10.5 10.5 4 12 5.5z"})}),Pt=({text:e="No templates found.",...t})=>(0,bt.jsx)("div",{className:"empty-container",...t,children:(0,bt.jsx)("p",{children:e})});function _t(){return _t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},_t.apply(this,arguments)}function Tt(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);t&&(n=n.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),r.push.apply(r,n)}return r}function Nt(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?Tt(Object(r),!0).forEach((function(t){Lt(e,t,r[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):Tt(Object(r)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))}))}return e}function Lt(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}class Et extends i().Component{constructor(e){let t;super(e),this.reCalculateColumnCount=this.reCalculateColumnCount.bind(this),this.reCalculateColumnCountDebounce=this.reCalculateColumnCountDebounce.bind(this),t=this.props.breakpointCols&&this.props.breakpointCols.default?this.props.breakpointCols.default:parseInt(this.props.breakpointCols)||2,this.state={columnCount:t}}componentDidMount(){this.reCalculateColumnCount(),window&&window.addEventListener("resize",this.reCalculateColumnCountDebounce)}componentDidUpdate(){this.reCalculateColumnCount()}componentWillUnmount(){window&&window.removeEventListener("resize",this.reCalculateColumnCountDebounce)}reCalculateColumnCountDebounce(){window&&window.requestAnimationFrame?(window.cancelAnimationFrame&&window.cancelAnimationFrame(this._lastRecalculateAnimationFrame),this._lastRecalculateAnimationFrame=window.requestAnimationFrame((()=>{this.reCalculateColumnCount()}))):this.reCalculateColumnCount()}reCalculateColumnCount(){const e=window&&window.innerWidth||1/0;let t=this.props.breakpointCols;"object"!=typeof t&&(t={default:parseInt(t)||2});let r=1/0,n=t.default||2;for(let o in t){const a=parseInt(o);a>0&&e<=a&&a<r&&(r=a,n=t[o])}n=Math.max(1,parseInt(n)||1),this.state.columnCount!==n&&this.setState({columnCount:n})}itemsInColumns(){const e=this.state.columnCount,t=new Array(e),r=i().Children.toArray(this.props.children);for(let n=0;n<r.length;n++){const o=n%e;t[o]||(t[o]=[]),t[o].push(r[n])}return t}renderColumns(){const{column:e,columnAttrs:t={},columnClassName:r}=this.props,n=this.itemsInColumns(),o=100/n.length+"%";let a=r;a&&"string"!=typeof a&&(this.logDeprecated('The property "columnClassName" requires a string'),void 0===a&&(a="my-masonry-grid_column"));const s=Nt(Nt(Nt({},e),t),{},{style:Nt(Nt({},t.style),{},{width:o}),className:a});return n.map(((e,t)=>i().createElement("div",_t({},s,{key:t}),e)))}logDeprecated(e){console.error("[Masonry]",e)}render(){const e=this.props,{children:t,breakpointCols:r,columnClassName:n,columnAttrs:o,column:a,className:s}=e,c=function(e,t){if(null==e)return{};var r,n,o=function(e,t){if(null==e)return{};var r,n,o={},a=Object.keys(e);for(n=0;n<a.length;n++)r=a[n],t.indexOf(r)>=0||(o[r]=e[r]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(n=0;n<a.length;n++)r=a[n],t.indexOf(r)>=0||Object.prototype.propertyIsEnumerable.call(e,r)&&(o[r]=e[r])}return o}(e,["children","breakpointCols","columnClassName","columnAttrs","column","className"]);let l=s;return"string"!=typeof s&&(this.logDeprecated('The property "className" requires a string'),void 0===s&&(l="my-masonry-grid")),i().createElement("div",_t({},c,{className:l}),this.renderColumns())}}Et.defaultProps={breakpointCols:void 0,className:void 0,columnClassName:void 0,children:void 0,columnAttrs:void 0,column:void 0};const Rt=Et,Ft=()=>(0,bt.jsx)("svg",{width:"13",height:"12",viewBox:"0 0 13 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,bt.jsx)("path",{d:"M5.85248 0.417179L4.3787 3.5203L1.0813 4.01952C0.489985 4.10859 0.253006 4.86562 0.681825 5.29921L3.06741 7.71327L2.50318 11.1234C2.40162 11.7398 3.02679 12.2016 3.5504 11.9133L6.50023 10.3031L9.45005 11.9133C9.97366 12.1992 10.5988 11.7398 10.4973 11.1234L9.93304 7.71327L12.3186 5.29921C12.7474 4.86562 12.5105 4.10859 11.9191 4.01952L8.62175 3.5203L7.14797 0.417179C6.88391 -0.135946 6.1188 -0.142977 5.85248 0.417179Z"})}),{Card:Dt,CardBody:$t,CardDivider:Mt,CardHeader:zt}=wp.components,Bt=e=>{const{title:t,onRequestClose:r,children:n,...o}=e;return(0,bt.jsx)("div",{className:"popup-container",...o,children:(0,bt.jsx)("div",{className:"inner",children:(0,bt.jsxs)(Dt,{children:[(0,bt.jsx)(zt,{children:(0,bt.jsxs)("div",{className:"inner-popup-header",children:[(0,bt.jsx)("h1",{children:t}),r&&(0,bt.jsx)("button",{className:"button-plain",onClick:()=>r(),children:(0,bt.jsx)(St,{})})]})}),(0,bt.jsx)(Mt,{}),(0,bt.jsx)($t,{children:(0,bt.jsx)("div",{className:"inner-popup-content",children:n})})]})})})},Gt=()=>(0,bt.jsxs)("div",{className:"animation-loader",children:[(0,bt.jsx)("div",{}),(0,bt.jsx)("div",{}),(0,bt.jsx)("div",{}),(0,bt.jsx)("div",{})]}),{ExternalLink:Wt,Button:Ht}=wp.components,{__:qt}=wp.i18n,{decodeEntities:Ut}=wp.htmlEntities,{__:Yt,sprintf:Vt}=wp.i18n,{Dashicon:Xt,Button:Zt,Card:Jt,CardBody:Kt,CardFooter:Qt}=wp.components,{addQueryArgs:er}=wp.url,tr=lt`
  0% {
    opacity: 0.7;
  }

  50% {
    opacity: 0.1;
  }

  100% {
    opacity: 0.7;
  }
`,rr=(ut.div`
	display: flex;
	margin-left: -25px;
	width: auto;

	img[src$="svg"].thumb {
		width: 33.3333%;
		padding-left: 25px;
		background-clip: padding-box;
		max-height: 300px;
		object-fit: cover;
		object-position: top;
		opacity: 0.7;
		transition: all 200ms ease-in-out;
		animation: ${tr} 2s linear infinite;
	}
`,ut.div`
	flex: 1;
	margin-left: 25px;

	.grid {
		display: flex;
		margin-left: -25px; /* gutter size offset */
		width: auto;
	}

	.grid-item {
		padding-left: 25px;
		background-clip: padding-box;

		&:empty {
			display: none;
		}

		> div {
			background: #fff;
			box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.05);
			position: relative;
			margin-bottom: 25px;
		}
	}

	figure {
		position: relative;
		overflow: hidden;
		margin: 0;
		min-height: 150px;
		display: flex;

		&:hover {
			.actions {
				opacity: 1;
				button {
					transform: none;
					opacity: 1;
				}
			}
			.favorite {
				opacity: 1;
			}
		}

		.pattern-title {
			position: absolute;
			bottom: 10px;
			text-align: center;
			width: 100%;
			font-size: 14px !important;
			text-transform: capitalize;
		}

		.actions {
			button {
				transform: translateY(20px);
				opacity: 0;
			}
			.ang-promo {
				text-decoration: none;
			}
		}
	}

	.favorite {
		position: absolute;
		top: 0;
		left: 0;
		z-index: 200;
		display: inline-flex;
		justify-content: center;
		align-items: center;
		width: 25px;
		height: 25px;
		box-shadow: none !important;
		outline: none !important;

		&:not(.is-active) {
			opacity: 0;
		}

		&:before {
			content: '';
			width: 0;
			height: 0;
			border-style: solid;
			border-width: 42px 42px 0 0;
			border-color: var(--ang-dark-bg) transparent transparent transparent;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 190;
		}

		svg {
			fill: #fff;
			position: relative;
			z-index: 195;
			width: 17px;
			height: 17px;
		}
		&.is-active svg {
			fill: #FFB443;
		}
	}

	img {
		max-width: 100%;
		height: auto;
		align-self: center;
	}

	img[src$="svg"] {
		width: 100%;
		height: 100%;
		object-fit: cover;
		max-height: 400px;
	}

	h3 {
		margin: 0;
		font-weight: normal;
		font-size: 16px;
		line-height: 21px;
	}

	 .content {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	 .components-base-control {
		margin-bottom: 30px;
	}

	.components-text-control__input, .components-text-control__input[type="text"] {
		background-color: #fff;
		color: #060606;
		font-size: 16px;
	}

	.button-plain {
		padding: 0;
		margin: 0;
		border: none;
		border-radius: 0;
		box-shadow: none;
		cursor: pointer;
		appearance: none;
		outline: 0;
		background: transparent;
		font-weight: bold;
		color: #060606;
		font-size: 14.22px;
	}
	.inner-popup-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: sticky;
		background: #fff;
	}
	.inner-popup-header h1 {
		font-size: 16px;
		font-weight: bold;
		color: #000000;
		margin: 0;
	}
	.inner-popup-content p {
		font-size: 13px;
		line-height: 18px;
		color: #565d65;
	}
`),nr=({state:e,importBlock:t,favorites:r,makeFavorite:n})=>{const o=React.useContext(dt),a=o.state.blocks.filter((e=>!("valid"!==AGWP.license.status&&o.state.showFree&&Boolean(e.is_pro)))),i=(AGWP.pluginURL,e=>!(e&&"valid"!==AGWP.license.status)),s=e=>AGWP.isContainer?e.thumbnail||AGWP.pluginURL+"assets/img/placeholder.svg":AGWP.blockMediaURL+e.id+".jpg";return(0,bt.jsxs)(React.Fragment,{children:[e.state.modalActive&&(0,bt.jsxs)(Bt,{title:Ut(e.state.activeBlock.title),style:{textAlign:"center"},onRequestClose:()=>{e.dispatch({activeBlock:!1,modalActive:!1,blockImported:!1})},children:[!e.state.blockImported&&(0,bt.jsx)(Gt,{}),e.state.blockImported&&(0,bt.jsxs)(React.Fragment,{children:[(0,bt.jsxs)("p",{children:[Vt(Yt("The %s has been imported and is now available in the","ang"),AGWP.isContainer?"container":"section")," ",(0,bt.jsx)("a",{target:"_blank",rel:"noopener noreferrer",href:er("edit.php",{post_type:"elementor_library",tabs_group:!0,elementor_library_type:AGWP.isContainer?"container":"section"}),children:Vt(Yt("Elementor %s library","ang"),AGWP.isContainer?"container":"section")}),"."]}),(0,bt.jsx)("p",{children:(0,bt.jsxs)(Zt,{isPrimary:!0,onClick:()=>{e.dispatch({activeBlock:!1,modalActive:!1,blockImported:!1})},children:[Yt("Ok, thanks","ang")," ",(0,bt.jsx)(Xt,{icon:"yes"})]})})]})]}),(0,bt.jsxs)(rr,{className:"blocks-area",children:[!o.state.syncing&&o.state.blocks.length<1&&(0,bt.jsx)(Pt,{text:Yt("No Templates found","ang")}),o.state.syncing&&o.state.blocks.length<1&&(0,bt.jsx)(Pt,{text:Yt("Loading Templates...","ang")}),(0,bt.jsx)(Rt,{breakpointCols:Boolean(AGWP.is_settings_page)?{default:5,2e3:4,1600:3,1300:2,900:1}:3,className:"grid",columnClassName:"grid-item block-list",children:a.length>=1&&a.map((e=>{let o=!1;if(e.requiredPlugins&&e.requiredPlugins.length>0){const t=e.requiredPlugins.filter((e=>""!==e&&!AGWP.activePlugins.includes(e)));if(t.length>0&&!t.includes("elementor-pro"))return null;o=t&&t.includes("elementor-pro")}return(0,bt.jsx)("div",{children:(0,bt.jsxs)(Jt,{children:[(0,bt.jsxs)(Kt,{children:[e.is_pro&&(0,bt.jsx)("span",{className:"pro",children:Yt("Pro","ang")}),(0,bt.jsxs)("figure",{children:[(0,bt.jsx)("img",{src:s(e),loading:"lazy",width:"900",height:"600",alt:e.title}),(0,bt.jsxs)("div",{className:"actions",children:[!i(e.is_pro)&&(0,bt.jsx)("a",{className:"ang-promo",href:"https://analogwp.com/style-kits-pro/?utm_medium=plugin&utm_source=library&utm_campaign=style+kits+pro",target:"_blank",children:(0,bt.jsx)(Zt,{isPrimary:!0,children:Yt("Go Pro","ang")})}),i(e.is_pro)&&o&&(0,bt.jsxs)("a",{className:"ang-requirements",href:"https://analogwp.com/style-kits-pro/?utm_medium=plugin&utm_source=library&utm_campaign=style+kits+pro",target:"_blank",children:[(0,bt.jsx)("img",{className:"required-logo",src:AGWP.pluginURL+"/assets/img/elementor.svg"}),(0,bt.jsx)("h4",{className:"title",children:"Elementor PRO"}),(0,bt.jsx)("p",{className:"description",children:"This pattern is using Elementor PRO widgets."})]}),(0,bt.jsx)(kr,{children:({add:r})=>!o&&i(e.is_pro)&&(0,bt.jsx)(Zt,{isPrimary:!0,onClick:()=>t(e,r),children:Yt("Import","ang")})}),AGWP.isContainer&&(0,bt.jsx)("div",{className:"pattern-title",children:(0,bt.jsx)("h3",{children:Ut(e.title)})})]}),(0,bt.jsx)("button",{className:jt()("button-plain favorite",{"is-active":e.id in r}),onClick:()=>n(e.id),children:(0,bt.jsx)(Ft,{})})]})]}),!AGWP.isContainer&&(0,bt.jsx)(Qt,{children:(0,bt.jsxs)("div",{className:"content",children:[(0,bt.jsx)("h3",{children:Ut(e.title)}),e.is_pro&&(0,bt.jsx)("span",{className:"pro",children:Yt("Pro","ang")})]})})]})},e.id)}))})]})]})},{__:or}=wp.i18n,{TextControl:ar,TabPanel:ir,ToggleControl:sr,Button:cr}=wp.components,lr="all-templates",ur=["favorites",lr],pr=ut.div`
	width: 100%;
	max-width: 220px;
	height: 100vh;
	position: sticky;
	position: -webkit-sticky;
	top: 35px;

	.components-tab-panel__tabs {
		display: flex;
		flex-direction: column;
	}

	.components-tab-panel__tabs > .components-button {
		text-transform: capitalize;
	}

	.components-toggle-control
	.components-base-control__field {
		flex-direction: row-reverse;
		justify-content: space-between;
	}

	.components-toggle-control
	.components-base-control__field
	.components-form-toggle {
		margin-right: 0;
	}

	.components-toggle-control
	.components-base-control__field
	.components-toggle-control__label {
		padding: 8px 0 10px;
	}

	.components-base-control.components-toggle-control {
		border-bottom: 1px solid var(--ang-border);
	}

	.block-categories-tabs .components-button {
		border-radius: 0;
		padding: 10px 0;
		font-size: 16px;
		color: #060606;
		justify-content: space-between;
	}

	.block-categories-tabs .components-button > span {
		color: rgba(0, 0, 0, 0.44);
		font-size: 14.22px;
		font-weight: normal;
	}

	.block-categories-tabs .components-button.active-tab {
		box-shadow: none;
		font-weight: bold;
		color: var(--ang-primary) !important;
	}

	.block-categories-tabs
	.components-button:not(:disabled):not([aria-disabled="true"]):not(.is-secondary):not(.is-primary):not(.is-tertiary):not(.is-link):hover,
	.components-button:focus:not(:disabled) {
		background-color: transparent;
		outline: none;
		box-shadow: none;
	}

	.block-categories-tabs .components-button:not([aria-disabled=true]):active {
		color: var(--ang-primary) !important;
	}

	.block-categories-tabs label,
	.components-toggle-control
	.components-base-control__field
	.components-toggle-control__label {
		font-size: 16px;
		color: #060606;
	}

	.block-categories-tabs {
		padding-right: 10px;
	}
`,dr=({state:e})=>{const t=React.useContext(dt),r=[...new Set(t.state.blockArchive.map((e=>e.tags[0])))];let n=t.state.blockArchive,o=n.filter((e=>e.id in t.state.blockFavorites));const a=e=>{const r=t.state.blockArchive,{blocksSearchInput:n}=t.state;let a=[];return e===lr&&(a=t.state.blockArchive),"favorites"===e&&(a=o),e!==lr&&"favorites"!==e&&(a=r.filter((t=>t.tags.indexOf(e)>-1))),"valid"!==AGWP.license.status&&t.state.showFree&&(a=a.filter((e=>!e.is_pro))),n&&(a=t.state.itemFilteredWithSearchTerm(a,n)),!!a&&a.length},i=()=>ur.concat(r.sort()),s=e=>{let t=a(e),r=t>0?t:0;return[`${e.replace(/-/g," ")} `,(0,bt.jsx)("span",{children:r},e)]},c=e=>e.filter((e=>a(e)>0)).map((e=>({name:e,title:s(e),className:`tab-${e}`})));return(0,bt.jsx)(pr,{className:"sidebar",children:c(i()).length>=1&&(0,bt.jsx)(ir,{className:"block-categories-tabs",activeClass:"active-tab",initialTabName:(e=>{let r=e||t.state.blocksTab;if("undefined"!=typeof elementor&&elementor&&elementor.config){const n=elementor.config.document.type,o=i();if(t.state.showFree&&"valid"!==AGWP.license.status)return r;switch(n){case"header":r=o.includes("Headers")?"Headers":e;break;case"footer":r=o.includes("Footers")?"Footers":e;break;case"single-page":case"single-post":case"page":r=o.includes("Post Templates")?"Post Templates":e}}return r})(t.state.blocksTab),onSelect:e=>{t.dispatch({blocksTab:e});let r=n;"favorites"===e&&(r=o),"favorites"!==e&&e!==lr&&(r=t.state.blockArchive.filter((t=>t.tags.indexOf(e)>-1)));const{blocksSearchInput:a}=t.state;a&&(r=t.state.itemFilteredWithSearchTerm(r,a)),t.dispatch({blocks:r})},tabs:c(i()),children:e=>null})})},{__:hr}=wp.i18n,{Component:fr,Fragment:mr}=wp.element,gr=ut.div`
	display: flex;
	justify-content: space-between;
	position: relative;
`,vr={blocks:[],activeBlock:!1,blockImported:!1,modalActive:!1};class br extends fr{static contextType=dt;constructor(){super(...arguments),this.state={...vr},this.importBlock=this.importBlock.bind(this),this.handleImport=this.handleImport.bind(this)}importBlock(e,t){this.setState({modalActive:!0,activeBlock:e}),this.handleImport(e,t)}handleImport(e,t){const r=Boolean(AGWP.is_settings_page)?"library":"elementor";(async function(e,t){return await ht({path:"/agwp/v1/blocks/insert",method:"post",data:{block:e,method:t}}).then((e=>e))})(e,r).then((e=>{"elementor"===r?(function(e,t="template"){let r=__("Template","ang");"block"===t&&(r=__("Block","ang"));let n=analog.insertIndex||-1;if("undefined"!=typeof $e){const t=$e.internal("document/history/start-log",{type:"add",title:`${__("Add Style Kits","ang")} ${r}`});for(let t=0;t<e.length;t++)$e.run("document/elements/create",{container:elementor.getPreviewContainer(),model:e[t],options:n>=0?{at:n++}:{}});$e.internal("document/history/end-log",{id:t})}else{const t=new Backbone.Model({getTitle:()=>"Test"});elementor.channels.data.trigger("template:before:insert",t);for(let t=0;t<json.data.content.length;t++)elementor.getPreviewView().addChildElement(e[t],n>=0?{at:n++}:null);elementor.channels.data.trigger("template:after:insert",{})}}(e.data.content,"block"),this.setState({modalActive:!1,activeBlock:!1}),window.analogModal.hide()):this.setState({blockImported:!0})})).catch((e=>{t(e.message,"error","import-error",!1),this.setState({modalActive:!1,activeBlock:!1})}))}getItemCount(e){const t=this.context.state.blocks.filter((t=>t.tags.indexOf(e)>-1));return!!t&&t.length}makeFavorite=e=>{const t=this.context.state.blockFavorites;if(this.context.markFavorite(e,!(e in t),"block"),e in t?delete t[e]:t[e]=!(e in t),this.context.dispatch({blockFavorites:t}),this.context.state.showing_favorites){const e=this.context.state.blocks.filter((e=>e.id in t));this.context.dispatch({blocks:e})}};render(){const e={state:this.state,dispatch:e=>this.setState(e)};return(0,bt.jsx)(mr,{children:(0,bt.jsxs)(gr,{children:[(0,bt.jsx)(dr,{state:e}),(0,bt.jsx)(nr,{state:e,importBlock:this.importBlock,favorites:this.context.state.blockFavorites,makeFavorite:this.makeFavorite})]})})}}function yr(e){return e.some((e=>!0===e.is_pro))}function xr(e){const t=moment.unix(e),r=moment.now();return Math.ceil(moment.duration(t.diff(r)).asMinutes())}const wr=React.createContext(),kr=(wr.Provider,wr.Consumer);class Cr extends React.Component{constructor(){super(...arguments),this.state={notices:[]},this.autoDismissTimeout=3e3,this.add=this.add.bind(this)}getNotices(){return this.state.notices.map((e=>(0,bt.jsx)(jr,{id:e.id,type:e.type,label:e.label,onDismiss:()=>this.remove(e.id),autoDismiss:!!e.autoDismiss&&e.autoDismiss,autoDismissTimeout:e.autoDismissTimeout?e.autoDismissTimeout:this.autoDismissTimeout},e.id)))}add(e,t="success",r=function(){let e=46656*Math.random()||0,t=46656*Math.random()||0;return e=("000"+e.toString(36)).slice(-3),t=("000"+t.toString(36)).slice(-3),e+t}(),n=!0,o=3e3){const a=[...this.state.notices,{label:e,id:r,type:t,autoDismiss:n,autoDismissTimeout:o}];this.setState({notices:a})}remove(e){const t=this.state.notices.filter((t=>t.id!==e));this.setState({notices:t})}onDismiss=e=>()=>this.remove(e);render(){const{add:e}=this,{children:t}=this.props;return(0,bt.jsxs)(wr.Provider,{value:{add:e},children:[(0,bt.jsx)("div",{className:"ang-notices",children:this.getNotices()}),t]})}}class jr extends React.Component{timeout=0;state={autoDismissTimeout:this.props.autoDismissTimeout,autoDismiss:this.props.autoDismiss};static defaultProps={autoDismiss:!1};static getDerivedStateFromProps({autoDismiss:e,autoDismissTimeout:t}){return e?{autoDismissTimeout:"number"==typeof e?e:t}:null}componentDidMount(){const{autoDismiss:e,onDismiss:t}=this.props,{autoDismissTimeout:r}=this.state;e&&(this.timeout=setTimeout(t,r))}componentWillUnmount(){this.timeout&&clearTimeout(this.timeout)}render(){const{onDismiss:e,label:t,id:r,type:n}=this.props;return(0,bt.jsxs)("div",{id:r,className:`notifications-container type-${n}`,children:[(0,bt.jsx)("div",{className:"notification-countdown",style:{opacity:this.state.autoDismiss?1:0,animation:`sk-notification-anim ${this.state.autoDismissTimeout}ms linear`,animationPlayState:"running"}}),(0,bt.jsx)("div",{className:"icon-wrapper",children:(o=n,"success"===o?(0,bt.jsx)(It,{}):"error"===o?(0,bt.jsx)(At,{}):(0,bt.jsx)(Ot,{}))}),(0,bt.jsx)("p",{children:t}),(0,bt.jsx)("button",{onClick:()=>e(),children:(0,bt.jsx)(St,{})})]});var o}}const{__:Sr}=wp.i18n,{Button:Ar}=wp.components,Or=()=>(0,bt.jsxs)("div",{children:[(0,bt.jsx)(dt.Consumer,{children:e=>(0,bt.jsx)(kr,{children:({add:t})=>(0,bt.jsx)(Ar,{isPrimary:!0,className:jt()("ang-sync",{"is-active":e.state.syncing}),onClick:r=>{r.preventDefault(),e.forceRefresh().then((()=>t(Sr("Library is now synced","ang")))).catch((()=>t(Sr("Something is not right, please try again.","ang"),"error")))},children:e.state.syncing?Sr("Syncing...","ang"):Sr("Sync Library","ang")})})}),!AGWP.is_settings_page&&(0,bt.jsxs)(Ar,{isSecondary:!0,className:"close-modal",children:[Sr("Close","ang")," ",(0,bt.jsx)(St,{})]})]}),Ir=lt`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`,Pr=ut.div`
	padding: 8px 24px;
	margin-bottom: 30px;
	background: #fff;
	border-bottom: 1px solid #DFDFDF;

	.ang-container {
		display: flex;
	    justify-content: space-between;
	    align-items: center;
	}

	.logo img {
		max-width: 42px;
		max-height: 42px;
	}

	a {
		color: #fff;
	}

	svg {
		vertical-align: bottom;
	}

	.button-plain {
		color: #fff !important;
		font-weight: bold;
		text-decoration: none;
		display: inline-flex;
		align-items: center;

		&.is-active {
			pointer-events: none;
			svg {
				animation: ${Ir} 2s linear infinite;
			}
		}

		svg {
			margin-left: 10px;
		}

		&:first-of-type {
			margin-left: auto;
		}
		+ .button-plain {
			position: relative;
			margin-left: 30px;
		}
	}

	.sync {
		text-transform: uppercase;
		font-size: 12.64px !important;
		letter-spacing: 1px;
	}
`,_r=()=>{const{theme:e}=React.useContext(vt);return(0,bt.jsx)(Pr,{theme:e,children:(0,bt.jsxs)("div",{className:"ang-container",children:[(0,bt.jsx)("div",{className:"logo",children:(0,bt.jsx)("img",{src:AGWP.pluginURL+"/assets/img/analog.svg",alt:""})}),!AGWP.isContainer&&(0,bt.jsx)(kt,{}),(0,bt.jsx)(Or,{})]})})},{apiFetch:Tr}=wp,Nr=ut.div`
	margin: 0 0 0 -20px;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	font-size: 13px;
	position: relative;

	--ang-accent: rgb(0, 112, 167);

	.ang-notices {
		position: fixed;
		right: 0;
		top: 75px;
		padding: 8px;
		z-index: 100000;
	}

	.components-form-toggle.is-checked .components-form-toggle__track {
		background-color: var(--ang-primary);
	}

	.components-form-toggle .components-form-toggle__input:focus + .components-form-toggle__track {
		box-shadow: 0 0 0 2px #fff, 0 0 0 4px var(--ang-primary);
	}

	.ang-button {
		font-size: 14.22px;
		font-weight: bold;
		text-align: center;
		border-radius: 4px;
		color: #fff;
		background: ${e=>e.theme.accent};
		padding: 12px 24px;
		display: inline-flex;
		justify-content: center;
		align-items: center;
		border: none;
		outline: 0;
		cursor: pointer;
		transition: all 200ms ease-in;
		min-width: 100px;
		text-decoration: none;
		box-sizing: border-box;
		height: auto;
		a {
			color: #fff !important;
			text-decoration: none;
		}

		&.secondary {
			background: #000222;
			border-radius: 0;
			text-transform: uppercase;
			font-size: 12px;
		}

		&:disabled {
			cursor: not-allowed;
			opacity: 0.4;
			filter: grayscale(1);
		}
	}

	a {
		outline: 0;
		box-shadow: none;
	}

	.button-plain {
		padding: 0;
		margin: 0;
		border: none;
		border-radius: 0;
		box-shadow: none;
		cursor: pointer;
		-webkit-appearance: none;
		appearance: none;
		outline: 0;
		background: transparent;
		font-weight: bold;
		color: #060606;
		font-size: 14.22px;
	}


	button {
		font-family: inherit;
	}

	.button-accent {
		background: var(--ang-accent);
		border: 0;
		border-radius: 0;
		text-transform: uppercase;
		font-size: 12px;
		letter-spacing: 1px;
		font-weight: bold;
		box-shadow: none;
		text-shadow: none;
		color: #fff;
		padding: 15px 24px;
		height: auto;
		&:focus,
		&:active {
			border: none !important;
			background: rgb(255, 120, 101, 0.9) !important;
			box-shadow: none !important;
			color: #fff !important;
		}
		&:hover {
			color: #fff;
			background: rgb(255, 120, 101, 0.9);
			border: none;
		}
	}

	.components-external-link {
		font-weight: 500;
	}

	.ang-link {
		color: var(--ang-accent);
		text-transform: uppercase;
		border-bottom: 1px solid var(--ang-accent);
		font-size: 12.64px;
		letter-spacing: 1px;
		text-decoration: none;
		font-weight: bold;
	}

	.preview-active .templates-list {
		visibility: hidden;
	}
`;class Lr extends React.Component{constructor(){super(...arguments),this.state={blocks:[],count:null,isOpen:!1,syncing:!1,favorites:AGWP.favorites,blockFavorites:AGWP.blockFavorites,showing_favorites:!1,blockArchive:[],showFree:!0,showPro:!0,group:!0,tab:"blocks",blocksTab:"all-templates",hasPro:!1,settings:{},blocksSearchInput:"",itemFilteredWithSearchTerm:function(e,t){let r=[];return e.filter((e=>(e.tags&&(r=e.tags.filter((e=>e.toLowerCase().includes(t)))),e.title.toLowerCase().includes(t)||r.length>=1)))}},this.refreshAPI=this.refreshAPI.bind(this),this.toggleFavorites=this.toggleFavorites.bind(this),this.handleSearch=this.handleSearch.bind(this),this.handleSort=this.handleSort.bind(this),this.handleFilter=this.handleFilter.bind(this),this.switchTabs=this.switchTabs.bind(this)}switchTabs(){const e=location.hash;["#blocks"].indexOf(e)>-1&&AGWP.is_settings_page&&this.setState({tab:e.substr(1),templates:this.state.archive,blocks:this.state.blockArchive,showing_favorites:!1})}async componentDidMount(){window.addEventListener("hashchange",this.switchTabs,!1),window.addEventListener("DOMContentLoaded",this.switchTabs,!1),"false"===window.localStorage.getItem("analog::show-free")&&this.setState({showFree:!1}),"false"===window.localStorage.getItem("analog::show-pro")&&this.setState({showPro:!1}),this.setState({syncing:!0});const e=await async function(){return await ht({path:"/agwp/v1/templates"}).then((e=>e))}(),t=e.library;this.setState({templates:t.templates,archive:t.templates,blockArchive:t.blocks,count:t.templates.length,timestamp:e.timestamp,hasPro:yr(t.templates),blocks:t.blocks,syncing:!1}),this.handleSort("latest"),document.addEventListener("modal-close",(()=>{this.setState({isOpen:!1,showing_favorites:!1,templates:this.state.archive})})),async function(){return await ht({path:"/agwp/v1/get/settings"}).then((e=>e))}().then((e=>this.setState({settings:e})))}handleFilter(e){const t=[...this.state.blockArchive];if("all"===e)return void this.setState({blocks:this.state.blockArchive});const r=t.filter((t=>t.tags[0]===e));this.setState({blocks:r})}handleSort(e){this.setState({showing_favorites:!1});const t=this.state.blocks;if("popular"===e){const e=t.sort(((e,t)=>{if("popularityIndex"in e){if(parseInt(e.popularityIndex)<parseInt(t.popularityIndex))return 1;if(parseInt(e.popularityIndex)>parseInt(t.popularityIndex))return-1}return 0}));this.setState({blocks:e})}if("latest"===e){const e=t.sort(((e,t)=>{if("published"in e){if(parseInt(xr(e.published))<parseInt(xr(t.published)))return 1;if(parseInt(xr(e.published))>parseInt(xr(t.published)))return-1}return 0}));this.setState({blocks:e})}}handleSearch(e,t="blocks"){let r=this.state.blockArchive,n=[],o=[];e&&(n=r.filter((r=>("patterns"===t&&r.keywords?o=r.keywords.filter((t=>t.toLowerCase().includes(e.toLowerCase()))):r.tags&&(o=r.tags.filter((t=>t.toLowerCase().includes(e.toLowerCase())))),r.title.toLowerCase().includes(e.toLowerCase())||o.length>=1))),n.length>0)?this.setState({blocks:n,blocksSearchInput:e}):this.setState({blocks:e?[]:this.state.blockArchive,blocksSearchInput:""})}async refreshAPI(){return this.setState({syncing:!0,blocksSearchInput:""}),wp.hooks.doAction("analog.refreshLibrary"),await Tr({path:"/agwp/v1/templates/?force_update=true"}).then((e=>{const t=e.library;this.setState({blockArchive:t.blocks,timestamp:e.timestamp,blocks:t.blocks,syncing:!1,blocksSearchInput:""})})).catch((()=>{this.setState({syncing:!1})}))}toggleFavorites(){this.setState({group:!1}),window.localStorage.setItem("analog::group-block",!1);const e=this.state.blockArchive.filter((e=>e.id in this.state.blockFavorites));this.setState({showing_favorites:!this.state.showing_favorites,blocks:this.state.showing_favorites?this.state.blockArchive:e})}render(){return(0,bt.jsx)(vt.Provider,{value:{theme:gt},children:(0,bt.jsx)(vt.Consumer,{children:({theme:e})=>(0,bt.jsx)(Nr,{theme:e,children:(0,bt.jsx)(Cr,{children:(0,bt.jsxs)(dt.Provider,{value:{state:this.state,forceRefresh:this.refreshAPI,markFavorite:ft,toggleFavorites:this.toggleFavorites,handleSearch:this.handleSearch,handleSort:this.handleSort,handleFilter:this.handleFilter,dispatch:e=>this.setState(e)},children:[(0,bt.jsx)(_r,{}),(0,bt.jsx)("div",{className:"analogwp-content",children:(0,bt.jsx)("div",{className:"ang-container",children:(this.state,(0,bt.jsx)(br,{}))})})]})})})})})}}const Er=Lr,Rr="analogwp-templates",Fr=(e,t)=>{document.getElementById(Rr)?t():setTimeout((function(){window.requestAnimationFrame((function(){Fr(e,t)}))}),1e3)};Fr(document.getElementById(Rr),(()=>{if(window.AGWP&&window.AGWP.wp_version&&window.AGWP.wp_version>="6.2"){const{createRoot:e}=wp.element;e(document.getElementById(Rr)).render((0,bt.jsx)(Er,{}))}else{const{render:e}=wp.element;e((0,bt.jsx)(Er,{}),document.getElementById(Rr))}}))})()})();