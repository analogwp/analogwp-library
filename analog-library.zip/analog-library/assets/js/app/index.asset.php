<?php return array('dependencies' => array('react', 'react-jsx-runtime'), 'version' => '406d48e06e20a4814ac0');
