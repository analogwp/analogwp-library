<?php return array('dependencies' => array('react', 'react-jsx-runtime'), 'version' => '335d36275f4cafdfcc0f');
